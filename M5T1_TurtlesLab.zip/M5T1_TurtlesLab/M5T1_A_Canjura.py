#Gabriela Canjura
#CTI 110
#10/09/2017
#M5T1 Turtle Lab A (square and triangle)

def main ():

    # draws a square and  triangle

    import turtle

    win = turtle.Screen()
    bob = turtle.Turtle()

    bob.pensize(2)             #changes shape, size and color
    bob.pencolor("blue")
    bob.shape("turtle")

    for i in range(4):         # draws a square
        bob.forward(100)
        bob.right(90)

    bob.penup()                # moves pen
    bob.goto(300,-100)
    bob.pendown()

    bob.left(180)              # rotates starting angle

    for i in range(3):         # draws triangle
        bob.forward(100)
        bob.right(120)

    win.mainloop()
    
main()
