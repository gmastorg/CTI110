#Gabriela Canjura
#CTI 110
#10/09/2017
#M5T1 Turtle Lab B (Initials)

def main ():

    # draws initials

    import turtle

    win = turtle.Screen()
    bob = turtle.Turtle()

    bob.pensize(6)
    bob.pencolor("purple")
    bob.shape("turtle")
    bob.speed(400)

    bob.penup()                # moves pen
    bob.goto(-300,0)
    bob.pendown()
    
    bob.left(160)

    # Draws G
    
    for i in range(240):
        bob.forward(1)
        bob.left(1)
    
    bob.penup()                
    bob.goto(-320,-50)
    bob.pendown()

    bob.left(-40)
        
    bob.forward(50)
    bob.right(90)
    bob.forward(70)

    # moves pen
    
    bob.penup()                
    bob.goto(-180,-110)
    bob.pendown()

    bob.left(175)

    # Draws M
    
    bob.forward(110)
    bob.right(145)
    bob.forward(70)
    bob.left(125)
    bob.forward(70)
    bob.right(145)
    bob.forward(110)

    # moves pen
    
    bob.penup()                
    bob.goto(70,0)
    bob.pendown()

    bob.left(240)
    
    # Draws C
    
    for i in range(240):
        bob.forward(1)
        bob.left(1)

    win.mainloop()
    
main()
