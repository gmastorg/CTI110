#Gabriela Canjura
#CTI 110
#10/09/2017
#M5T1 Turtle Lab C (Snowflake)

def main ():

    # draws initials

    import turtle

    win = turtle.Screen()
    bob = turtle.Turtle()

    bob.pensize(6)
    bob.pencolor("green")
    bob.shape("turtle")
    bob.speed(400)

    for n in range(10):

        bob.left(25)

        for z in range(4):
            bob.forward(30)
            bob.left(60)
            bob.forward(30)
            bob.right(120)

    bob.pencolor("blue")

    bob.penup()
    bob.goto(-50,0)
    bob.pendown()

    for z in range(15):

        bob.left(25)

        for z in range(4):
            bob.forward(60)
            bob.left(60)
            bob.forward(60)
            bob.right(120)

    bob.pencolor("purple")

    bob.penup()
    bob.goto(-120,-30)
    bob.pendown()
    
    for x in range(20):

        bob.left(25)
        
        for i in range(4):
            bob.forward(110)
            bob.left(60)
            bob.forward(110)
            bob.right(120)
                
    win.mainloop()
    
main()
